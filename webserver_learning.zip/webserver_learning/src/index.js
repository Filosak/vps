const express = require("express");
const app = express();
const PORT = 8080;

app.use(express.json())
app.use("/", express.static("public"))


// 0: {
//     "name": "Rick-roll",
//     "lenght": "2:25"
// }

let currPlaying = null;
let size = 0;
let songs = {
    
};


app.listen(PORT, () => {
    console.log("Server listening on PORT", PORT);
});

/*
    Tahle část je pro klienta
*/
app.get('/getSongs', (req, res) => {
    res.status(202).send({
        "songs": songs,
        "size": size
    });
})


app.post("/postSongs", (req, res) => {
    songs[size] = req.body;
    size++;
    res.status(201).send("dyk");
})


/*
    Bot si vezme všechny poslaný linky za posledních x sekund -> uloží je do queue -> až budou stažený pošlou se pro zobrazení klientovy
*/
let sizeLinks = 0;
let songsLinks = {
    
};

// tuhle část posílá klient hotovo
app.post("/postSongsLinks", (req, res) => {
    songsLinks[sizeLinks] = req.body;
    sizeLinks++;
    res.status(201).send("dyk");
})

// tohle získává bot
app.get('/getSongsLinks', (req, res) => {
    res.status(202).send({
        "links": songsLinks,
        "size": sizeLinks
    });

    songsLinks = {};
})