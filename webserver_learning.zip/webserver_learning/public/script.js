/*
    POST
*/

let form = document.querySelector(".formular");

form.addEventListener("submit", (e) => {
    e.preventDefault();

    let link = document.querySelector(".link");

    let postBody = {
        "link": link.value,
    }

    form.reset();

    const options = {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(postBody)
      };
      
    fetch('http://localhost:8080/postSongsLinks', options)
        .then(response => console.log(response))
        .catch(err => console.error(err));
});



/*
    GET
*/

// vars
let allSongs = document.querySelector(".allSongs");

// every x secs fetch than reload allsongs
window.addEventListener('load', function () {
    var fetchInterval = 5000;
    setInterval(fetchStatus, fetchInterval);
});

function fetchStatus() {
    fetch('http://localhost:8080/getSongs')
        .then(respones => respones.json())
        .then(data => updateAllSongs(data))
}


function updateAllSongs(data) {
    let songs = data["songs"]
    let size = data["size"]

    allSongs.innerHTML = "";
    for (let i = 0; i < size; i++) {
        let songName = songs[i]["name"];
        let songLenght = songs[i]["lenght"];
        
        let li = document.createElement("li");
        let img = document.createElement("img");
        let p1 = document.createElement("p");
        let p2 = document.createElement("p");

        li.classList.add("allSongs-object");
        img.classList.add("allSongs-object-image");
        p1.classList.add("allSongs-object-name");
        p2.classList.add("allSongs-object-lenght");

        img.src = "images/test.png";
        p1.textContent = songName;
        p2.textContent = songLenght;

        li.appendChild(img);
        li.appendChild(p1);
        li.appendChild(p2);

        allSongs.appendChild(li);
    }
}








// let songsList = document.querySelector(".allSongs");

// let songs = 
// {
//     0: {
//         "name": "Rick-roll",
//         "lenght": "2:25"
//     },

//     1: {
//         "name": "Bitch-lasagne",
//         "lenght": "1:50"
//     },
// }
// let currPlaying = 0;
// let size = 2;

// for (let i = 0; i < size; i++) {
//     let songName = songs[i]["name"];
//     let songLenght = songs[i]["lenght"];
    
//     let li = document.createElement("li");
//     let img = document.createElement("img");
//     let p1 = document.createElement("p");
//     let p2 = document.createElement("p");

//     li.classList.add("allSongs-object");
//     img.classList.add("allSongs-object-image");
//     p1.classList.add("allSongs-object-name");
//     p2.classList.add("allSongs-object-lenght");

//     img.src = "images/test.png";
//     p1.textContent = songName;
//     p2.textContent = songLenght;

//     li.appendChild(img);
//     li.appendChild(p1);
//     li.appendChild(p2);

//     songsList.appendChild(li);
// }


/* 
<li class="allSongs-object">   
    <img src="images/test.png" class="allSongs-object-image">
    <p class="allSongs-object-name">Rick-roll</p>
    <p class="allSongs-object-index">0</p>
</li> 
*/